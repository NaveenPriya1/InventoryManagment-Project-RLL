import { Dealer } from './dealer';

describe('Dealer', () => {
  it('should create an instance', () => {
    expect(new Dealer()).toBeTruthy();
  });
});
