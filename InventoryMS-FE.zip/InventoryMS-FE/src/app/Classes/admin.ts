export class Admin {
    ausername!:string;
    apassword!:string;
}
